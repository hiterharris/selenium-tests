exports.handler = async () => {
    const message = 'hello'
    console.log('message: ', message)
    return message
};
